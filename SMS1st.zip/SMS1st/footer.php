<footer id="pagefooter">
<div id="f-content">
<img src="images/MW Logo.jpg" width="96" height="125" alt="MW Logo" id="footerimg">
<div id="credits">
<p class="sitecredit"> 2018 @ All Rights Reserved | </p>
<p class="designcredit">NACIT S. I. S</p>

</div>
</div>

</footer>

</body>
</html>
