<?php include("header.php");?>
<section id="page"><font color="#FFFFFF"></font>
<header id="pageheader" class="homeheader">
<h1 class="sitedescription"><h2>&nbsp;</h2></h1>
</header>


<article class="post">
<header class="postheader">
<h1><a href="#">Student Management System</a></h1><h3>&nbsp;</h3>
<h3><i>National College of Information Technology (NACIT)</i></h3>
<a href="#"></a></p>
</header>
<p><b>Student Management Systems are the primary systems for operating  colleges. The Student Management System is a student-level data collection  system that allows the Department to collect and analyze more accurate and  comprehensive information. The systems provide capabilities for  entering student records, tracking student attendance, and managing many other  student-related data needs in a college or university.</b></p>
</article>
<article class="post">
<header class="postheader">
<h1>The Student Management System Supports:</h1><p class="postinfo">&nbsp;</p>
</header>
<p><b>•	Handling inquiries from prospective students.</b></p>
<p><b>•	Handling the Student details.  </b></p>
<p><b>•	Maintaining the Student Marks Details.  </b></p>
<p><b>•	Handling Student Attendance Records.  </b></p>
<p><b>•	Maintaining records of absences and attendance.  </b></p>
<p><b>•	Maintaining records of Internal marks.</b></p>
</article>
<div class="clear"></div>

<div class="clear"></div>
</section>
</div>
<?php include("footer.php"); ?>